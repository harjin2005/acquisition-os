# CURRENT_STATE.md — What is done so far

**This file is the shared memory between all sessions. Every session updates it when finished.**
**Keep it short. Newest at top.**

_Last updated: (not started yet)_

## Project status
- Phase: NOT STARTED — repo is empty, Sprint 1 not begun.
- All design docs are complete and live in `/docs/product/`.
- Next milestone: M1 — foundation deployed (repo, CI, auth, database with security).

## What's built
- Nothing yet.

## What's in progress
- Nothing yet.

## Known problems / things to watch
- ADR-006 is still open (team size / budget undecided) — does not block Sprint 1.
- Vendor data contract not signed yet — does not block Sprint 1 (we build against fake test data first).

## Log (newest first)
- (empty — first session will add the first entry here)
