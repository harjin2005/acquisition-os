# NEXT_TASK.md — The ONE task the current session should do

**Only one task lives here at a time. The founder (or the Architect session) sets it.**

## Current task
**Session:** ARCHITECT (session 1)
**Goal:** Set up the project foundation ONLY. Do not build features yet.

Steps:
1. Read `docs/product/31-execution-plan.md`, the "Sprint 1" section only.
2. Create the empty repository folder structure exactly as described in
   `docs/product/30-engineering-handbook.md` section 2.
3. Set up the basic tooling (the project config files) so the project can run locally.
4. Do NOT write any product features. Foundation only.
5. When done: update `CURRENT_STATE.md`, and write the next task here for the Backend session.

**Definition of done:** a fresh checkout can install and start locally, and a health-check
endpoint returns OK. Show the founder the command output proving it works.

**If anything is unclear:** follow `STOP_RULES.md` — stop and ask one question.
